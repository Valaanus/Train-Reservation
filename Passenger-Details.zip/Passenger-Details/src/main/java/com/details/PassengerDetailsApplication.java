package com.details;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PassengerDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PassengerDetailsApplication.class, args);
	}

}
